<?php

namespace Tests\Elements\Nested;

use \Tests\Elements\Nested\BaseNestedTest;

use \Shoprunback\Elements\Customer;

final class CustomerTest extends BaseNestedTest
{
    use \Tests\Elements\CustomerTrait;
}