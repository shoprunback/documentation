<?php

namespace Shoprunback\Error;

class ElementCannotGetAll extends Error
{
}