<?php

namespace Shoprunback\Error;

class ElementCannotBeUpdated extends Error
{
}