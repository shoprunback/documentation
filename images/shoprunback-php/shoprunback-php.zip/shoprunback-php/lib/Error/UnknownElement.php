<?php

namespace Shoprunback\Error;

class UnknownElement extends Error
{
}