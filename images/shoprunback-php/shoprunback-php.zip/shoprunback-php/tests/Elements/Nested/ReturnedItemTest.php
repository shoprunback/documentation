<?php

namespace Tests\Elements\Nested;

use \Tests\Elements\Nested\BaseNestedTest;

use \Shoprunback\Elements\ReturnedItem;

final class ReturnedItemTest extends BaseNestedTest
{
    use \Tests\Elements\ReturnedItemTrait;
}