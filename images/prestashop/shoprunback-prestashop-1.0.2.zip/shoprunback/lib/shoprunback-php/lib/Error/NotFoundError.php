<?php

namespace Shoprunback\Error;

class NotFoundError extends Error
{
}