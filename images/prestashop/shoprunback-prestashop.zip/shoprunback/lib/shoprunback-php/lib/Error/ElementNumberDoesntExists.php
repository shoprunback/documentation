<?php

namespace Shoprunback\Error;

class ElementNumberDoesntExists extends Error
{
}